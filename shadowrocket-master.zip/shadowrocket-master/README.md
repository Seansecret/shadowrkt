# Shadowrocket小火箭在线安装 
- 共享Shadowrocket小火箭账号，请大家有条件情况下支持正版！

- Shadowrocket小火箭 在线安装地址 https://lueyingpro.github.io/shadowrocket/index.html
- 如打开闪退，可使用 APPID 登录App Store 下载最新版本

- 我很荣幸能为您提供帮助，希望能够支持正版版本，谢谢
- I am very honored to help you, I hope to support the genuine version, thank you
  

# AppId 解锁时段通知
-  13:10-13:20
-  22:10-22:30
- 在此时段所有appid接受邮件解锁，其他时间不受理！望周知，人力有限，望海涵！

##### 请使用app id 的时候只在 app store登录，以免对您的造成不必要的损失 ！

### 服务购买
https://lueying.online



# 如果有帮到您，请打赏一杯卡布奇诺，谢谢！


<img src="./421582951065_.pic.jpg" width = "300" height = "400" alt="二维码赞赏" align=center />


# Telegram 群组
  * [@lueying](https://t.me/lueying) 
  * [掠影官方群组](https://t.me/lueying_b)
  * [掠影官方订阅频道](https://t.me/lueying_a)
